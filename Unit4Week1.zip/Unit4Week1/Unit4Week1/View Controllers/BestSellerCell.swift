//
//  BestSellerCell.swift
//  Unit4Week1
//
//  Created by Lisa J on 12/17/17.
//  Copyright © 2017 Lisa J. All rights reserved.
//

import UIKit

class BestSellerCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var weeksLabel: UILabel!
}
