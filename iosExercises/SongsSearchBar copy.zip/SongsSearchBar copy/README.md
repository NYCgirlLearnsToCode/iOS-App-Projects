# SongsSearchBar

## Level 1

- Display **loveSongs** song in the tableview.
- Use a subtitle cell to display the song name in the ```textLabel``` and the artist name in the ```detailTextLabel```.
- Click on a tableview cell and segue to a detailview that displays the name of the song, the artist, and the default image.

## Level 2

- Add a searchBar.
- Allow the user to search based on the song name.

## Level 3 

- Create scope buttons called artist and title.
- Allow the user to search based on artist and song depending on which scope button was selected.

![](https://media.giphy.com/media/xUOxfkpNxGMCEwQi3u/giphy.gif)

## Level 4 

- Show a message in the tableview when there are no search results found.
- Dismiss the keyboard when the search results return no search results. 
