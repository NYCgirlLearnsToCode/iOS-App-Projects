//
//  YelpAPIKeys.swift
//  FindASpot
//
//  Created by Lisa J on 1/19/18.
//  Copyright © 2018 Lisa J. All rights reserved.
//

import Foundation

struct YelpAPIKeys {
    static let baseSearchUrl = "https://api.yelp.com/v3/businesses/search?term="
    static let apiKey = "jUz5lSVtCvOM3ChXsfA4ouZl9FreoGuy9iKbkYC2UW83-BuOPVkk3a0UxYOZ_p_QpC8mVsnwK9tlXdAxKBVoNXbDH25Cs72uoI-RB67iPGmm2S6G0Vzf1-jbmIZhWnYx"
}
